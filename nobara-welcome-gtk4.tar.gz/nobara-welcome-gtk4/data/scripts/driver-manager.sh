#!/bin/bash
nobara-drivers "$@"