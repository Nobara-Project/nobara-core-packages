#!/bin/bash
nobara-sync "$@"

### Put an update script that output info to terminal stdout
