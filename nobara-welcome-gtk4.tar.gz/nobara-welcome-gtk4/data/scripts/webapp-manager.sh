#!/bin/bash
webapp-manager "$@"