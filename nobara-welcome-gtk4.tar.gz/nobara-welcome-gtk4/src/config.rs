pub const APP_ID: &str = "com.github.nobaraproject.nobarawelcome";
pub const DISTRO_ICON: &str = "fedora-logo-icon";
pub const VERSION: &str = env!("CARGO_PKG_VERSION");
pub const APP_ICON: &str = "com.github.nobaraproject.nobarawelcome";
pub const APP_GITHUB: &str = "https://github.com/Nobara-Project/nobara-core-packages/";
